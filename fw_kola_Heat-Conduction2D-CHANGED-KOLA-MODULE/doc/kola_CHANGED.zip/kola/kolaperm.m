clear all;close all;clc

k0=2.5e-14;
D = 900;

k0=1.8e-14;
D = 950;

z    =[1000         3000        5000        7000];
lk   =[-14.2         -15          -16          -17];

k=10.^lk;kA=k0*exp(-z/D);


figure
plot(k,z,'or','MarkerSize',8);hold on
plot(kA,z,'-b','MarkerSize',8);hold on
ylim([0 8000]);xlim([5e-18  5e-14]);grid on
set(gca,'Ydir','reverse','XScale','log');
xlabel('log10 k');ylabel('z(m)');title('Kola Borehole: Permeability')